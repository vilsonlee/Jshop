DROP TABLE IF EXISTS `jshop_stock`;
DROP TABLE IF EXISTS `jshop_stock_log`;